from google_trans_new import google_translator 
import googletrans 
import sqlite3
import os



translator = google_translator()


translate_list=["Language Selection","Select file","Which file type is this?","The Converted File","The Key File","The Character List","The file to Convert","Submit","Where to encrypt to","Where to decrypt to","Encryption Tool","Encryption Tool","Encryption","Decryption","Settings","Chunk Size","Chunk Size per thread in bytes","Cpu Threads","No Charlist File","No Converted file","No Key file","No File to convert","Start Converting","Encryption Tool Progress","Progress at "]    
    



conn = sqlite3.connect('data/multi_languages.db')

c = conn.cursor()
languages = googletrans.LANGUAGES
for language in languages:
    #try:
        print(languages[language])
        print("""CREATE TABLE IF NOT EXISTS '"""+language+"""' (language_long text,to_translate_text text, translation text)""")
        c.execute("""CREATE TABLE IF NOT EXISTS '"""+language+"""' (language_long text,to_translate_text text, translation text)""")
        c.execute("""SELECT EXISTS(SELECT 1 FROM '"""+language+"""' WHERE language_long='"""+languages[language]+"""')""")
        if(str(c.fetchone())=="(1,)"):
                print("already exists")
        else:
                c.execute("""INSERT INTO '"""+language+"""'(language_long) VALUES('"""+languages[language]+"""')""")
        for translation_text in translate_list:
            translation_txt=translation_text.replace("'",'"')
            print("Lädt jetzt "+translation_txt)
            c.execute("""SELECT EXISTS(SELECT 1 FROM '"""+language+"""' WHERE to_translate_text='"""+translation_txt+"""')""")
            if(str(c.fetchone())=="(1,)"):
                print("already exists")
            else:
                result = translator.translate(translation_txt,lang_tgt=language)
                print(result)
                if(type(result)==list):
                    result = result[0].replace("'",'"')
                else:
                    result = result.replace("'",'"')
                
                print("""INSERT INTO '"""+language+"""'(to_translate_text, translation) VALUES('"""+translation_txt+"""','"""+result+"""')""")
                c.execute("""INSERT INTO '"""+language+"""'(to_translate_text, translation) VALUES('"""+translation_txt+"""','"""+result+"""')""")
                print("writing ended")
			
            conn.commit()
  # except:
    #    print("failure")
#



c.execute("SELECT name FROM sqlite_master WHERE type='table'")
for row in c:
    print(row)

conn.commit()