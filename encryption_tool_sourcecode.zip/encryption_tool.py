from tkinter import *
from tkinter import font
from tkinter import ttk
from tkinter import filedialog
from TkinterDnD2 import *
from PIL import ImageTk, Image
import multiprocessing as mp
import subprocess
import pkg_resources.py2_warn
import sqlite3
import json
import ast
language_conn = sqlite3.connect('data/multi_languages.db', check_same_thread=False).cursor()


def translate_text(search_value,language):

    try:
        language=ast.literal_eval(language)
        search_target=search_value.replace("'",'"')
        language_conn.execute("""SELECT translation FROM '"""+language[0]+"""' WHERE to_translate_text='"""+search_target+"""'""")
        result=language_conn.fetchone()
        if(result==None):
            return search_target
        else:
            return result[0]
    except:
        return search_target


class setup_main_window():
    languages_list=[]
    chunk_name_choices = ["1 MB","2 MB","4 MB","8 MB","16 MB","32 MB","64 MB","128 MB","256 MB","512 MB","1 GB","2 GB","4 GB","8GB","16 GB","32 GB","64 GB","ENDLESS"]
    chunkvalue_choices = [1000000,2000000,4000000,8000000,16000000,32000000,64000000,128000000,256000000,512000000,1000000000,2000000000,4000000000,8000000000,16000000000,32000000000,64000000000,1000000000000000000]
    cputhreads_choices = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,32,64,128,256,512,1024]
    
    def reload_main_window(self):
        self.root.destroy()
        setup_main_window()
        
    def save_setting(self,args_list):
        for key,value in args_list:
            self.settings_json[key]=value
        with open('data/settings.json', 'w') as json_file:
            json.dump(self.settings_json, json_file,indent=4)
        self.reload_main_window()
    
    def set_settings(self):
        with open('data/settings.json') as json_file:
            self.settings_json = json.load(json_file)
        self.language_menu_var.set(self.settings_json["language"])
        
        
    def get_languages(self):
        language_conn.execute("""SELECT name FROM sqlite_master WHERE type='table'""")
        for row in language_conn.fetchall():
            language_conn.execute("""SELECT language_long FROM '"""+row[0]+"""' WHERE language_long IS NOT NULL""")
            self.languages_list.append([row[0],language_conn.fetchone()[0]])
        
    def opnfile_explorer(self,file_type):
        self.filename = filedialog.askopenfilename(initialdir = "/",title = translate_text("Select file",self.settings_json["language"]),filetypes = (("all files","*.*"),("lost","*.lost")))
        if(self.filename!=""):
                self.set_filepath(file_type,self.filename)
                
    def set_filepath(self,filetype,path):
        if(path[0]=="{" and path[-1]=="}"):
            path =path[1:-1]   
        if(filetype=="converted"):
            self.convertedfile_path=path
            self.convertedfile_button['text']=self.convertedfile_path
        if(filetype=="key"):
            self.keyfile_path=path
            self.keyfile_button['text']=self.keyfile_path
        if(filetype=="charlist"):
            self.charlistfile_path=path
            self.charlstfile_button['text']=self.charlistfile_path
        if(filetype=="toconvert"):
            self.toconvertfile_path=path
            self.filetoconvert_button['text']=self.toconvertfile_path
            
            
    def crypt_button(self,state):
        if(state=="encryption"):
            self.filetoconvert_button.grid(row=4, column=2)
            self.charlstfile_button.grid_remove()
            self.convertedfile_button.grid_remove()
            self.keyfile_button.grid_remove()
            self.encrypt_button.configure(state=DISABLED)
            self.encrypt_button.configure(bg="#ff66cc")
            self.decrypt_button.configure(state=NORMAL)
            self.decrypt_button.configure(bg="#00cc00")
            self.crypt_state="encryption"
            
        else:
            self.charlstfile_button.grid(row=5, column=2)
            self.convertedfile_button.grid(row=4, column=2)
            self.keyfile_button.grid(row=4, column=3)
            self.filetoconvert_button.grid_remove()
            self.encrypt_button.configure(state=NORMAL)
            self.encrypt_button.configure(bg="#00cc00")
            self.decrypt_button.configure(state=DISABLED)
            self.decrypt_button.configure(bg="#ff66cc")
            self.crypt_state="decryption"

    
    def set_chunksizeperthread(self):
        return int(self.chunkvalue_choices[self.chunk_name_choices.index(self.chunkmenue_var.get())]/int(self.cpucores_menu_var.get()))

        
    def on_drop(self,event):
        self.prompt = Toplevel()
        Label(self.prompt, text=translate_text("Which file type is this?",self.settings_json["language"])).grid()
        self.var_prompt = IntVar()
        for i, option in enumerate([translate_text("The Converted File",self.settings_json["language"]),translate_text("The Key File",self.settings_json["language"]),translate_text("The Character List",self.settings_json["language"]),translate_text("The file to Convert",self.settings_json["language"])]):
            Radiobutton(self.prompt, text=option, variable=self.var_prompt, value=i).grid(sticky=W)
        Button(self.prompt,text=translate_text("Submit",self.settings_json["language"]), command=self.prompt.destroy).grid()
        self.root.wait_window(self.prompt) 
        if(self.var_prompt.get()==0):
                self.set_filepath("converted",event.data)
        if(self.var_prompt.get()==1):
                self.set_filepath("key",event.data)
        if(self.var_prompt.get()==2):
                self.set_filepath("charlist",event.data)
        if(self.var_prompt.get()==3):
                self.set_filepath("toconvert",event.data)
                
    def encryptor_start(self):
        if(self.crypt_state=="encryption"):
            subprocess.Popen(["converter/converter.exe", "encrypt", str(self.toconvertfile_path), str(filedialog.askdirectory(title = translate_text("Where to encrypt to",self.settings_json["language"]))), str(self.chunkvalue_choices[self.chunk_name_choices.index(self.chunkmenue_var.get())]), str(self.set_chunksizeperthread()), str(self.cpucores_menu_var.get()),str(self.settings_json["language"])])
        if(self.crypt_state=="decryption"):
            subprocess.Popen(["converter/converter.exe", "decrypt", str(self.convertedfile_path), str(self.keyfile_path),str(self.charlistfile_path), str(filedialog.askdirectory(title = translate_text("Where to decrypt to",self.settings_json["language"]))), str(self.chunkvalue_choices[self.chunk_name_choices.index(self.chunkmenue_var.get())]), str(self.set_chunksizeperthread()), str(self.cpucores_menu_var.get()),str(self.settings_json["language"])])

        
    def __init__(self):
        self.root = TkinterDnD.Tk()
        ###Set vars
        self.cpucores_menu_var = StringVar(self.root)
        self.cpucores_menu_var.set(mp.cpu_count())
        self.language_menu_var = StringVar(self.root)
        self.chunkmenue_var = StringVar(self.root)
        self.chunkmenue_var.set("1 MB")
        self.crypt_state=""
        self.convertedfile_path=None
        self.keyfile_path=None
        self.charlistfile_path=None
        self.toconvertfile_path=None
        self.set_settings()
        self.get_languages()
        self.root.title(translate_text("Encryption Tool",self.settings_json["language"]))
        self.title_lbl=Label(self.root, text=translate_text("Encryption Tool",self.settings_json["language"]), font="Arial 40 bold",relief=FLAT )
        self.title_lbl.grid(column=2)
        self.encrypt_button = Button(self.root, text=translate_text("Encryption",self.settings_json["language"]), state=NORMAL, font="Arial 15 bold",bg="#ff66cc",activebackground="#ff66cc",height=1,width=20,relief=GROOVE,command= lambda:self.crypt_button("encryption"))
        self.encrypt_button.grid(row=1, column=2,padx=10, pady=30)
        self.decrypt_button = Button(self.root, text=translate_text("Decryption",self.settings_json["language"]), state=NORMAL, font="Arial 15 bold",bg="#ff66cc",activebackground="#00cc00",height=1,width=20,relief=GROOVE,command= lambda:self.crypt_button("decryption"))
        self.decrypt_button.grid(row=1, column=3, padx=10, pady=30)
        
        
        self.settings_lbl = Label(self.root, text=translate_text("Settings",self.settings_json["language"]),font="Arial 40 bold",relief=FLAT )
        self.settings_lbl.grid(row=2, column=0,pady=30)
        
        self.languages_lbl = Label(self.root, text=translate_text("Language Selection",self.settings_json["language"]),font="Arial 20 bold",relief=FLAT )
        self.languages_lbl.grid(row=3, column=0,padx=30,pady=10)
        self.languages_menu =  OptionMenu(self.root, self.language_menu_var, *self.languages_list)
        self.languages_menu.grid(row=4, column=0,padx=30,pady=30)
        self.language_menu_var.trace("w",lambda a,b,c:self.save_setting([["language",self.language_menu_var.get()]]))
        
        self.chunksizetxt_lbl = Label(self.root, text=translate_text("Chunk Size",self.settings_json["language"]),font="Arial 20 bold",relief=FLAT )
        self.chunksizetxt_lbl.grid(row=5, column=0,padx=30,pady=10)
        self.chunk_menu =  OptionMenu(self.root, self.chunkmenue_var, *self.chunk_name_choices)
        self.chunk_menu.grid(row=6, column=0,padx=30,pady=10)
        self.chunkthreadtxt_lbl = Label(self.root, text=translate_text("Chunk Size per thread in bytes",self.settings_json["language"]),font="Arial 10 bold",relief=FLAT )
        self.chunkthreadtxt_lbl.grid(row=7, column=0,padx=30,pady=10)
        self.chunkperthread_lbl = Label(self.root, text=self.set_chunksizeperthread(),font=font.Font(family="Arial", size=10),relief=GROOVE )
        self.chunkperthread_lbl.grid(row=8, column=0,padx=30,pady=10)
        self.chunkmenue_var.trace("w", lambda a,b,c:self.chunkperthread_lbl.configure(text=self.set_chunksizeperthread()))
        self.cpucores_menu_var.trace("w",lambda a,b,c:self.chunkperthread_lbl.configure(text=self.set_chunksizeperthread()))
        
        self.cpucores_lbl = Label(self.root, text=translate_text("Cpu Threads",self.settings_json["language"]),font="Arial 20 bold",relief=FLAT )
        self.cpucores_lbl.grid(row=9, column=0,padx=30,pady=5)
        self.cpucores_menu =  OptionMenu(self.root, self.cpucores_menu_var, *self.cputhreads_choices)
        self.cpucores_menu.grid(row=10, column=0,padx=30,pady=30)
        
       
        self.drop_img=ImageTk.PhotoImage(Image.open("data/drop.png").resize((614,170)))
        self.img_panel = Label(self.root, image = self.drop_img)
        self.img_panel.grid(row=10, column=2,rowspan=2,columnspan=2)
        self.img_panel.drop_target_register(DND_FILES)
        self.img_panel.dnd_bind('<<Drop>>', self.on_drop)
        
        
        self.charlstfile_button = Button(self.root, text=translate_text("No Charlist File",self.settings_json["language"]), font="Arial 15 bold",height=1,width=15,relief=GROOVE,command= lambda:self.opnfile_explorer("charlist"))
        self.charlstfile_button.grid(row=5, column=2)
        self.convertedfile_button = Button(self.root, text=translate_text("No Converted file",self.settings_json["language"]), font="Arial 15 bold",height=1,width=15,relief=GROOVE,command= lambda:self.opnfile_explorer("converted"))
        self.convertedfile_button.grid(row=4, column=2)
        self.keyfile_button = Button(self.root, text=translate_text("No Key file",self.settings_json["language"]), font="Arial 15 bold",height=1,width=15,relief=GROOVE,command= lambda:self.opnfile_explorer("key"))
        self.keyfile_button.grid(row=4, column=3)
        self.filetoconvert_button = Button(self.root, text=translate_text("No File to convert",self.settings_json["language"]), font="Arial 15 bold",height=1,width=15,relief=GROOVE,command= lambda:self.opnfile_explorer("toconvert"))
        self.filetoconvert_button.grid(row=4, column=2)
        self.charlstfile_button.grid_remove()
        self.convertedfile_button.grid_remove()
        self.keyfile_button.grid_remove()
        self.filetoconvert_button.grid_remove()
        
        
        
        self.start_crypt = Button(self.root, text=translate_text("Start Converting",self.settings_json["language"]),bg="#33ccff", font="Arial 15 bold",height=1,width=20,relief=GROOVE,command= self.encryptor_start)
        self.start_crypt.grid(row=2, column=3)
        
        


        self.root.mainloop()


setup_main_window()




