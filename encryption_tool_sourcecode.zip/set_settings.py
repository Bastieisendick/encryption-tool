import json




settings_dict = {
"language": "('en', 'english')",
}

with open('data/settings.json', 'w') as json_file:
    json.dump(settings_dict, json_file,indent=4)
    
    
    
with open('data/settings.json') as f:
    data = json.load(f)
  
print(data)