import time
import pickle
import os 
import multiprocessing as mp
import sys
from tkinter import *
from tkinter import ttk
from threading import Thread
from functools import partial
import sqlite3
import ast
import numpy


language_conn = sqlite3.connect('data/multi_languages.db', check_same_thread=False).cursor()



def translate_text(search_value,language):

    try:
        language=ast.literal_eval(language)
        search_target=search_value.replace("'",'"')
        language_conn.execute("""SELECT translation FROM '"""+language[0]+"""' WHERE to_translate_text='"""+search_target+"""'""")
        result=language_conn.fetchone()
        if(result==None):
            return search_target
        else:
            return result[0]
    except:
        return search_target



class encrypt():
    def __init__(self,args_list=None):
            self.toconvertfile_path=args_list[0]
            self.encrypt_folder=args_list[1]
            self.chunk_int=int(args_list[2])
            self.chunkstringlen=int(args_list[3])
            self.cpu_cores=int(args_list[4])
            self.headpath,self.tailpath = os.path.split(self.toconvertfile_path)
            self.splitted_path = self.tailpath.split(".")
            self.converted_file_path=self.splitted_path[-1]
            self.key_file_path="".join(self.tailpath).replace("."+self.converted_file_path, '')
            time.sleep(2)
            self.set_chars()
            self.len_pos_char_list=int(len(self.possible_char))
            
    def set_possible_chars(self):

        with open('data/possible_char.lst', 'r', encoding="iso-8859-1", newline='\n') as filehandle:
            self.possible_char = list(dict.fromkeys(list(filehandle.read())))
        with open(self.toconvertfile_path,"r", encoding="iso-8859-1", newline='\n') as convert_f:
            with open(self.encrypt_folder+"/character.lst","wb") as list_f:
                file_value=convert_f.read()
                for char in list(set(file_value)):
                    try:
                        self.possible_char.index(str(char))
                    except:
                        self.possible_char.append(char)
                pickle.dump(self.possible_char, list_f)
        self.len_pos_char_list=int(len(self.possible_char))
 
    def set_chars(self):
        try:
            with open(self.encrypt_folder+"/character.lst","rb") as list_f:
                self.possible_char = pickle.load(list_f)
        except:
            self.possible_char=""
    def convert_chunk(self,value_text,chunk_size):
            randoms_list=numpy.random.randint(self.len_pos_char_list, size=chunk_size)
            chunk_list=[[value_text[0+i:self.chunkstringlen+i],randoms_list[0+i:self.chunkstringlen+i]] for i in range(0, chunk_size, self.chunkstringlen)]
            returned_data = self.p.map(self.evaluate_func, chunk_list)
            c_flist,key_flist=zip(*returned_data)
            with open(self.encrypt_folder+"/converted."+self.converted_file_path, 'a', encoding="iso-8859-1", newline='\n') as c_f:
                c_f.write("".join(c_flist))
            with open(self.encrypt_folder+"/key."+self.key_file_path, 'a', encoding="iso-8859-1", newline='\n') as key_f:
                key_f.write("".join(key_flist))
            


    def main(self):
        self.p = mp.Pool(int(self.cpu_cores))
        with open(self.encrypt_folder+"/converted."+self.converted_file_path, 'w', encoding="iso-8859-1", newline='\n') as c_f:
            c_f.write("")
        with open(self.encrypt_folder+"/key."+self.key_file_path, 'w', encoding="iso-8859-1", newline='\n') as key_f:
           key_f.write("")
        self.evaluate_func = partial(encrypt_prcs, self.possible_char)
        chunk_stage=0
        file_size=int(os.path.getsize(self.toconvertfile_path))
        progress.config(mode = 'determinate',maximum=file_size, value = 0)
        progress.start()
        #start_time=time.time() add these lines to print out the time to encrypt your files
        try:
            with open(self.toconvertfile_path,"r", encoding="iso-8859-1", newline='\n') as nc_f:
                for chunk in iter(lambda: nc_f.read(self.chunk_int)  , ""):
                    size_of_chunk=len(chunk)
                    self.convert_chunk(chunk,size_of_chunk)
                    chunk_stage+=size_of_chunk
                    update_progress = Thread(target=progress_bar_update, args=(chunk_stage,file_size,size_of_chunk,))
                    update_progress.setDaemon(True)
                    update_progress.start()
                progress.stop()
        except:
            progress.stop()
        #print(time.time()-start_time) add these lines to print out the time to encrypt your files

def encrypt_prcs(possible_char,chunk_list):
        c_file_value=""
        key_file_value=""
        for i in range(0,len(chunk_list[0])):
            char_int=possible_char.index(str(chunk_list[0][i]))
            c_file_value=c_file_value+possible_char[int(char_int)-int(chunk_list[1][i])]
            key_file_value=key_file_value+possible_char[chunk_list[1][i]]
        return c_file_value,key_file_value
        
          
          
          
          
          
          
class decrypt():
    def __init__(self,args_list=None):
        self.convertedfile_path=args_list[0]
        self.keyfile_path=args_list[1]
        self.charlistfile_path=args_list[2]
        self.decrypt_folder=args_list[3]
        self.chunk_int=int(args_list[4])
        self.chunkstringlen=int(args_list[5])
        self.cpu_cores=int(args_list[6])
        self.output_file_name = os.path.split(self.keyfile_path)[1].replace('key.', '', 1)
        self.output_file_ending = os.path.split(self.convertedfile_path)[1].replace('converted.', '', 1)
        self.set_possible_chars()
        self.len_pos_char_list=int(len(self.possible_char))
        
        
    def set_possible_chars(self):
        with open(self.charlistfile_path,"rb") as list_f:
            self.possible_char = pickle.load(list_f)

    def convert_chunk(self,chunk_key,chunk_text,chunk_size):
            chunk_list=[[chunk_key[0+i:self.chunkstringlen+i],chunk_text[0+i:self.chunkstringlen+i]] for i in range(0, chunk_size, self.chunkstringlen)]
            returned_data = self.p.map(self.evaluate_func, chunk_list)
            with open(self.decrypt_folder+"/"+str(self.output_file_name+"."+self.output_file_ending), 'a', encoding="iso-8859-1", newline='\n') as output_f:
                output_f.write("".join(returned_data))
             
    def main(self):
        self.p = mp.Pool(int(self.cpu_cores))
        with open(self.decrypt_folder+"/"+str(self.output_file_name+"."+self.output_file_ending), 'w', encoding="iso-8859-1", newline='\n') as output_f:
            output_f.write("")
        self.evaluate_func = partial(decrypt_prcs, self.len_pos_char_list,self.possible_char)
        chunk_stage=0
        file_size=int(os.path.getsize(self.convertedfile_path))
        progress.config(mode = 'determinate',maximum=file_size, value = 0)
        progress.start()
        #start_time=time.time()    add these lines to print out the time to encrypt your files
        try:
            with open(self.convertedfile_path, "r", encoding="iso-8859-1", newline='\n') as c_f:
                with open(self.keyfile_path, "r", encoding="iso-8859-1", newline='\n') as key_f:
                    for chunk_key,chunk_text in zip(iter(lambda: key_f.read(self.chunk_int), ""),iter(lambda: c_f.read(self.chunk_int), "")):
                        size_of_chunk=len(chunk_text)
                        self.convert_chunk(chunk_key,chunk_text,size_of_chunk)
                        chunk_stage+=size_of_chunk
                        update_progress = Thread(target=progress_bar_update, args=(chunk_stage,file_size,size_of_chunk,))
                        update_progress.setDaemon(True)
                        update_progress.start()
                    progress.stop()
        except:
            progress.stop()
        #print(time.time()-start_time)     add these lines to print out the time to encrypt your files

def decrypt_prcs(len_pos_char_list,possible_char,value_text):
    output_value=""
    for i in range(0,len(value_text[1])):
        conv_int=int(possible_char.index(str(value_text[1][i])))+int(possible_char.index(str(value_text[0][i])))
        if(int(conv_int)>=len_pos_char_list):
            conv_int=int(conv_int)-len_pos_char_list
        output_value+=possible_char[int(conv_int)]
    return output_value


def setup_progress_bar():
    global progress
    global progress_descrption
    progress_bar = Tk()
    progress_bar.title(translate_text("Encryption Tool Progress",general_language))
    progress_descrption = Label(progress_bar, text=translate_text("Progress at ",general_language)+"0% \n 0 bytes:0 bytes")
    progress_descrption.grid(row=0, column=0)
    progress = ttk.Progressbar(progress_bar, orient = HORIZONTAL, length = 200)
    progress.grid(row=1, column=0)
    progress_bar.mainloop()
    
def progress_bar_update(chunk_stage,file_size,size_of_chunk):
    try:
        progress.step(size_of_chunk)
        progress_descrption.configure(text=translate_text("Progress at ",general_language)+str(int((chunk_stage/file_size)*100))+"% \n"+str(chunk_stage)+" bytes : "+ str(file_size)+" bytes")
        progress_descrption.update()
    except:
        pass
        
        
mp.freeze_support()
if __name__ == '__main__':
    general_language=sys.argv[-1]
    if(sys.argv[1]=="encrypt"):
        arguments_list=[sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6]]        
        cryption_class=encrypt(args_list=arguments_list)
    elif(sys.argv[1]=="decrypt"):   
        arguments_list=[sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6],sys.argv[7],sys.argv[8]]     
        cryption_class=decrypt(args_list=arguments_list)
    cryption_class.set_possible_chars()
    progress_bar_thread = Thread(target=setup_progress_bar, args=())
    progress_bar_thread.setDaemon(True)
    progress_bar_thread.start()
    cryption_class.main()

